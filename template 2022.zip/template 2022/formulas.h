#ifndef FORMULAS_H_INCLUDED
#define FORMULAS_H_INCLUDED
#include "math.h"

int checkOverlap( int object1X, int object1width,
                    int object1Y, int object1height,
                    int object2X, int object2width,
                    int object2Y, int object2height);


#endif //FORMULAS_H_INCLUDED
